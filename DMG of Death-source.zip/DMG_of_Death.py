from __future__ import annotations

import sys
import time
import subprocess
import os
from pathlib import Path

# --- PyQt6 Imports ---
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap, QIcon
from PyQt6.QtWidgets import (
    QApplication, QWidget, QSplashScreen, QMainWindow, QVBoxLayout, QHBoxLayout,
    QPushButton, QFileDialog, QLabel, QLineEdit, QTextEdit, QProgressBar,
    QMessageBox, QComboBox
)

# --- Global Definitions ---
APP_NAME = "DMG of Death"
ORG_NAME = "Death's Head Software"
SPLASH_DURATION = 5.4

# =============================================================================
# Resource Path Helper
# =============================================================================

def resource_path(filename: str) -> Path:
    """
    Returns the correct path to a bundled resource whether running as a
    PyInstaller bundle (sys._MEIPASS) or as a plain script.
    Also checks the current working directory as a fallback.
    """
    # PyInstaller extracts to a temp folder referenced by sys._MEIPASS
    if hasattr(sys, '_MEIPASS'):
        p = Path(sys._MEIPASS) / filename
        if p.exists():
            return p
    # Running as a script - check next to the .py file
    p = Path(__file__).parent / filename
    if p.exists():
        return p
    # Last resort - current working directory
    return Path(filename)

# =============================================================================
# Splash Function
# =============================================================================

def create_splash():
    """
    Creates the QSplashScreen matching the suite standard (as seen in Editor of Death etc).
    Loads splash.png scaled to 600x600 (KeepAspectRatio on a square image = no bars),
    paints title at top and org name at bottom, returns a 600x600 splash.
    Falls back to ASCII skull on a dark canvas if splash.png not found.
    """
    try:
        splash_path = resource_path("splash.png")

        if splash_path.exists():
            img = QPixmap(str(splash_path))
            if not img.isNull():
                # Scale square image to 600x600 - no bars, fills the window
                pixmap = img.scaled(600, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                    Qt.TransformationMode.SmoothTransformation)
            else:
                pixmap = QPixmap(600, 600)
                pixmap.fill(QColor(20, 20, 20))
        else:
            # Fallback: dark canvas with ASCII skull
            pixmap = QPixmap(600, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            for i, line in enumerate(skull_art):
                painter.drawText(150, 220 + (i * 30), line)
            painter.end()

        painter = QPainter(pixmap)

        # Title
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 36, QFont.Weight.Bold))
        r = pixmap.rect(); r.setTop(15); r.setBottom(75)
        painter.drawText(r, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)

        # Org name
        painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        fr = pixmap.rect(); fr.setTop(pixmap.height() - 70); fr.setBottom(pixmap.height() - 20)
        painter.drawText(fr, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)

        painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None

# =============================================================================
# DMG Creation Worker Thread
# =============================================================================

class DMGCreationWorker(QThread):
    """Worker thread for creating DMG files without blocking the UI."""
    progress = pyqtSignal(str)
    finished = pyqtSignal(bool, str)
    
    def __init__(self, app_path: str, output_path: str, dmg_name: str, compression: str):
        super().__init__()
        self.app_path = app_path
        self.output_path = output_path
        self.dmg_name = dmg_name
        self.compression = compression
    
    def run(self):
        try:
            # Validate input
            if not os.path.exists(self.app_path):
                self.finished.emit(False, f"Error: Application path does not exist: {self.app_path}")
                return

            if not os.path.isdir(self.output_path):
                self.finished.emit(False, f"Error: Output directory does not exist: {self.output_path}")
                return

            # Ensure DMG name ends with .dmg
            if not self.dmg_name.endswith('.dmg'):
                self.dmg_name += '.dmg'

            dmg_full_path = os.path.join(self.output_path, self.dmg_name)

            # Check if DMG already exists
            if os.path.exists(dmg_full_path):
                self.finished.emit(False, f"Error: DMG file already exists: {dmg_full_path}")
                return

            self.progress.emit("Building DMG staging folder...")

            import shutil
            import tempfile

            # UDZO = zlib-compressed, good compatibility.
            # UDBZ = bzip2-compressed, better ratio (Maximum setting).
            dmg_format = 'UDBZ' if self.compression == 'Maximum' else 'UDZO'
            vol_name = os.path.splitext(self.dmg_name)[0]

            # Stage folder: app bundle + /Applications symlink for drag-install UX
            stage_dir = tempfile.mkdtemp(prefix="dmg_stage_")
            try:
                app_name = os.path.basename(self.app_path)
                # ditto preserves bundle structure, code signatures, and extended attributes
                result = subprocess.run(
                    ['ditto', self.app_path, os.path.join(stage_dir, app_name)],
                    capture_output=True, text=True
                )
                if result.returncode != 0:
                    self.finished.emit(False, f"Error staging app: {result.stderr.strip()}")
                    return
                os.symlink("/Applications", os.path.join(stage_dir, "Applications"))

                self.progress.emit("Creating DMG...")

                cmd = [
                    'hdiutil', 'create',
                    '-volname', vol_name,
                    '-srcfolder', stage_dir,
                    '-format', dmg_format,
                    dmg_full_path
                ]

                result = subprocess.run(cmd, capture_output=True, text=True)
            finally:
                shutil.rmtree(stage_dir, ignore_errors=True)

            if result.returncode != 0:
                self.finished.emit(False, f"Error creating DMG: {result.stderr.strip()}")
                return

            self.finished.emit(True, f"Successfully created DMG: {dmg_full_path}")

        except Exception as e:
            self.finished.emit(False, f"Unexpected error: {str(e)}")

# =============================================================================
# Main Application Window
# =============================================================================

class DMGOfDeathApp(QMainWindow):
    """Main application window for DMG creation."""
    
    def __init__(self):
        super().__init__()
        self.worker = None
        self.init_ui()
        self.apply_dark_theme()
    
    def init_ui(self):
        """Initialize the user interface."""
        self.setWindowTitle(APP_NAME)
        self.setGeometry(100, 100, 700, 600)
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)
        
        # Title
        title_label = QLabel(APP_NAME)
        title_font = QFont("Courier", 24, QFont.Weight.Bold)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(title_label)
        
        # Subtitle
        subtitle_label = QLabel("Convert macOS Applications to DMG Files")
        subtitle_font = QFont("Courier", 12)
        subtitle_label.setFont(subtitle_font)
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(subtitle_label)
        
        main_layout.addSpacing(20)
        
        # Application Path Section
        app_path_label = QLabel("Application Path:")
        app_path_label.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        main_layout.addWidget(app_path_label)
        
        app_path_layout = QHBoxLayout()
        self.app_path_input = QLineEdit()
        self.app_path_input.setPlaceholderText("Select an .app file...")
        app_path_layout.addWidget(self.app_path_input)
        
        browse_app_btn = QPushButton("Browse")
        browse_app_btn.clicked.connect(self.browse_app)
        app_path_layout.addWidget(browse_app_btn)
        
        main_layout.addLayout(app_path_layout)
        
        main_layout.addSpacing(15)
        
        # Output Path Section
        output_path_label = QLabel("Output Directory:")
        output_path_label.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        main_layout.addWidget(output_path_label)
        
        output_path_layout = QHBoxLayout()
        self.output_path_input = QLineEdit()
        self.output_path_input.setPlaceholderText("Select output directory...")
        self.output_path_input.setText(str(Path.home() / "Desktop"))
        output_path_layout.addWidget(self.output_path_input)
        
        browse_output_btn = QPushButton("Browse")
        browse_output_btn.clicked.connect(self.browse_output)
        output_path_layout.addWidget(browse_output_btn)
        
        main_layout.addLayout(output_path_layout)
        
        main_layout.addSpacing(15)
        
        # DMG Name Section
        dmg_name_label = QLabel("DMG Filename:")
        dmg_name_label.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        main_layout.addWidget(dmg_name_label)
        
        self.dmg_name_input = QLineEdit()
        self.dmg_name_input.setPlaceholderText("Enter DMG filename (without .dmg extension)...")
        main_layout.addWidget(self.dmg_name_input)
        
        main_layout.addSpacing(15)
        
        # Compression Section
        compression_label = QLabel("Compression Level:")
        compression_label.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        main_layout.addWidget(compression_label)
        
        self.compression_combo = QComboBox()
        self.compression_combo.addItems(["Standard", "Maximum"])
        main_layout.addWidget(self.compression_combo)
        
        main_layout.addSpacing(20)
        
        # Progress Bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)
        
        # Status/Log Area
        status_label = QLabel("Status:")
        status_label.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        main_layout.addWidget(status_label)
        
        self.status_text = QTextEdit()
        self.status_text.setReadOnly(True)
        self.status_text.setMaximumHeight(150)
        main_layout.addWidget(self.status_text)
        
        main_layout.addSpacing(15)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        create_btn = QPushButton("Create DMG")
        create_btn.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        create_btn.clicked.connect(self.create_dmg)
        button_layout.addWidget(create_btn)
        
        clear_btn = QPushButton("Clear")
        clear_btn.setFont(QFont("Courier", 11, QFont.Weight.Bold))
        clear_btn.clicked.connect(self.clear_fields)
        button_layout.addWidget(clear_btn)
        
        main_layout.addLayout(button_layout)
        
        main_layout.addStretch()
    
    def apply_dark_theme(self):
        """Apply a dark theme to the application."""
        dark_stylesheet = """
            QMainWindow {
                background-color: #1e1e1e;
            }
            QWidget {
                background-color: #1e1e1e;
                color: #ffffff;
            }
            QLabel {
                color: #ffffff;
            }
            QLineEdit {
                background-color: #2d2d2d;
                color: #ffffff;
                border: 1px solid #444444;
                border-radius: 4px;
                padding: 5px;
            }
            QLineEdit:focus {
                border: 1px solid #666666;
            }
            QTextEdit {
                background-color: #2d2d2d;
                color: #ffffff;
                border: 1px solid #444444;
                border-radius: 4px;
            }
            QPushButton {
                background-color: #404040;
                color: #ffffff;
                border: 1px solid #555555;
                border-radius: 4px;
                padding: 8px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #505050;
            }
            QPushButton:pressed {
                background-color: #303030;
            }
            QComboBox {
                background-color: #2d2d2d;
                color: #ffffff;
                border: 1px solid #444444;
                border-radius: 4px;
                padding: 5px;
            }
            QComboBox::drop-down {
                border: none;
            }
            QComboBox::down-arrow {
                image: none;
            }
            QComboBox QAbstractItemView {
                background-color: #2d2d2d;
                color: #ffffff;
                selection-background-color: #404040;
            }
            QProgressBar {
                background-color: #2d2d2d;
                border: 1px solid #444444;
                border-radius: 4px;
                text-align: center;
                color: #ffffff;
            }
            QProgressBar::chunk {
                background-color: #4a7c59;
            }
        """
        self.setStyleSheet(dark_stylesheet)
    
    def browse_app(self):
        """Open file dialog to select an application."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Application",
            str(Path.home() / "Applications"),
            "macOS Applications (*.app);;All Files (*)"
        )
        if file_path:
            self.app_path_input.setText(file_path)
            # Auto-fill DMG name based on app name
            app_name = os.path.splitext(os.path.basename(file_path))[0]
            self.dmg_name_input.setText(app_name)
    
    def browse_output(self):
        """Open directory dialog to select output location."""
        dir_path = QFileDialog.getExistingDirectory(
            self,
            "Select Output Directory",
            str(Path.home() / "Desktop")
        )
        if dir_path:
            self.output_path_input.setText(dir_path)
    
    def create_dmg(self):
        """Start the DMG creation process."""
        app_path = self.app_path_input.text().strip()
        output_path = self.output_path_input.text().strip()
        dmg_name = self.dmg_name_input.text().strip()
        compression = self.compression_combo.currentText()
        
        # Validation
        if not app_path:
            QMessageBox.warning(self, "Input Error", "Please select an application.")
            return
        
        if not output_path:
            QMessageBox.warning(self, "Input Error", "Please select an output directory.")
            return
        
        if not dmg_name:
            QMessageBox.warning(self, "Input Error", "Please enter a DMG filename.")
            return
        
        # Disable button and show progress
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.status_text.clear()
        self.status_text.append("Starting DMG creation...")
        
        # Create worker thread
        self.worker = DMGCreationWorker(app_path, output_path, dmg_name, compression)
        self.worker.progress.connect(self.update_status)
        self.worker.finished.connect(self.on_dmg_creation_finished)
        self.worker.start()
    
    def update_status(self, message: str):
        """Update the status text area."""
        self.status_text.append(message)
        self.progress_bar.setValue((self.progress_bar.value() + 25) % 100)
    
    def on_dmg_creation_finished(self, success: bool, message: str):
        """Handle DMG creation completion."""
        self.progress_bar.setVisible(False)
        self.status_text.append(message)
        
        if success:
            QMessageBox.information(self, "Success", message)
        else:
            QMessageBox.critical(self, "Error", message)
    
    def clear_fields(self):
        """Clear all input fields."""
        self.app_path_input.clear()
        self.dmg_name_input.clear()
        self.output_path_input.setText(str(Path.home() / "Desktop"))
        self.status_text.clear()
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(False)

# =============================================================================
# Main Entry Point
# =============================================================================

if __name__ == '__main__':
    app = QApplication(sys.argv)
    
    # Create and show splash screen
    splash = create_splash()
    
    if splash:
        splash.show()
        
        # Show splash messages
        messages = ["Initializing...", "Loading components...", "Preparing interface...", "Almost ready..."]
        delay_per_message = SPLASH_DURATION / len(messages)
        
        for message in messages:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + message,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255)
            )
            app.processEvents()
            time.sleep(delay_per_message)
        
        # Create main window
        main_window = DMGOfDeathApp()
        main_window.show()
        
        # Close splash screen
        splash.finish(main_window)
    else:
        # Fallback if splash creation fails
        main_window = DMGOfDeathApp()
        main_window.show()
    
    sys.exit(app.exec())